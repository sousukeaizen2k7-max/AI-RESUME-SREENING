/**
 * AI Resume Screening System - Lightweight Local Server
 * Zero dependencies, runs directly on Node.js (v25+)
 * Run with: node server.js
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.txt': 'text/plain; charset=utf-8',
  '.pdf': 'application/pdf',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
};

const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // Normalize URL
  let pathname = '/index.html';
  try {
    const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    pathname = parsedUrl.pathname;
    if (pathname === '/' || pathname === '') {
      pathname = '/index.html';
    }
  } catch (e) {
    pathname = req.url.split('?')[0];
    if (pathname === '/' || pathname === '') pathname = '/index.html';
  }

  const safePath = path.normalize(decodeURIComponent(pathname)).replace(/^(\.\.[\/\\])+/, '');
  const filePath = path.join(ROOT_DIR, safePath);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      console.log(`[${new Date().toLocaleTimeString()}] 404 Not Found: ${pathname}`);
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found: ' + pathname);
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    console.log(`[${new Date().toLocaleTimeString()}] 200 OK: ${pathname} (${stats.size} bytes)`);

    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'Cache-Control': 'no-cache'
    });

    const readStream = fs.createReadStream(filePath);
    readStream.pipe(res);
  });
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n❌ Error: Port ${PORT} is already in use by another process.`);
    console.error(`👉 Try running on a different port: PORT=3001 node server.js\n`);
  } else {
    console.error(`\n❌ Server error:`, err);
  }
  process.exit(1);
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`===============================================================`);
  console.log(`✨ AI Resume Screening System - Web Server Active`);
  console.log(`📡 Local URL:      http://127.0.0.1:${PORT}`);
  console.log(`📁 Serving from:   ${ROOT_DIR}`);
  console.log(`⚙️  Node Version:   ${process.version}`);
  console.log(`🛑 Press Ctrl+C in terminal to stop the server anytime.`);
  console.log(`===============================================================`);
  console.log(`\n[${new Date().toLocaleTimeString()}] Waiting for incoming requests...`);
});
