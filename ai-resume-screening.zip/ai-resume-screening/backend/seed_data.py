"""
AI Resume Screening System - Seed Data Script
Initializes SQLite database with default candidates and job postings.
"""

from database import init_db, insert_or_update_candidate
import json

SAMPLE_SEED_CANDIDATES = [
    {
        "id": "cand-1",
        "name": "Alex Rivera",
        "email": "alex.rivera@techpulse.io",
        "phone": "+1 (555) 234-8901",
        "location": "San Francisco, CA",
        "role": "Senior Full Stack Engineer",
        "experience_years": 6.5,
        "overall_score": 92,
        "skills_score": 95,
        "experience_score": 94,
        "education_score": 90,
        "domain_score": 88,
        "matched_skills": ["React", "TypeScript", "Node.js", "Python", "Docker", "AWS", "PostgreSQL", "REST API", "Git", "CI/CD"],
        "missing_skills": ["Kubernetes", "GraphQL"],
        "education": "B.S. Computer Science, UC Berkeley (2019)",
        "status": "Shortlisted",
        "summary": "Outstanding technical alignment with over 6 years of proven experience in React, Python, Docker, and AWS.",
        "applied_date": "2026-09-26"
    },
    {
        "id": "cand-2",
        "name": "Dr. Sophia Chen",
        "email": "sophia.chen.ai@datamind.org",
        "phone": "+1 (555) 789-4321",
        "location": "Boston, MA",
        "role": "Lead AI & Machine Learning Scientist",
        "experience_years": 5.2,
        "overall_score": 94,
        "skills_score": 98,
        "experience_score": 92,
        "education_score": 96,
        "domain_score": 93,
        "matched_skills": ["Python", "PyTorch", "Scikit-Learn", "NLP", "Transformers", "SQL", "Docker", "GCP", "Git", "FastAPI"],
        "missing_skills": ["MLflow", "LangChain"],
        "education": "M.S. in AI & Data Science, MIT (2019)",
        "status": "Shortlisted",
        "summary": "Top-tier candidate with advanced academic credentials from MIT and 5+ years of cutting-edge NLP production deployment.",
        "applied_date": "2026-09-25"
    },
    {
        "id": "cand-3",
        "name": "Marcus Vance",
        "email": "marcus.vance@cloudforge.net",
        "phone": "+1 (555) 456-1122",
        "location": "Seattle, WA",
        "role": "Senior DevOps & Cloud Infrastructure Engineer",
        "experience_years": 7.2,
        "overall_score": 91,
        "skills_score": 94,
        "experience_score": 96,
        "education_score": 85,
        "domain_score": 90,
        "matched_skills": ["AWS", "Docker", "Kubernetes", "Terraform", "CI/CD", "Linux", "Python", "Bash", "Prometheus", "Git"],
        "missing_skills": ["Ansible", "Vault"],
        "education": "B.S. Information Technology, Univ. of Washington (2018)",
        "status": "Shortlisted",
        "summary": "Senior DevOps practitioner holding dual CKA and AWS Architect credentials with over 7 years managing Kubernetes.",
        "applied_date": "2026-09-24"
    }
]

def seed():
    init_db()
    for cand in SAMPLE_SEED_CANDIDATES:
        insert_or_update_candidate(cand)
    print("Database seeded with sample candidates.")

if __name__ == "__main__":
    seed()
