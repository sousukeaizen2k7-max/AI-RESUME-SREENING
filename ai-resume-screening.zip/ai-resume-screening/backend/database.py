"""
AI Resume Screening System - SQLite Database Manager
Provides persistence for candidates, job descriptions, and screening scores.
"""

import sqlite3
import json
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "screening.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Jobs Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        department TEXT,
        min_experience REAL,
        education_required TEXT,
        required_skills TEXT,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Candidates Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS candidates (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        phone TEXT,
        location TEXT,
        role TEXT,
        experience_years REAL,
        overall_score INTEGER,
        skills_score INTEGER,
        experience_score INTEGER,
        education_score INTEGER,
        domain_score INTEGER,
        matched_skills TEXT,
        missing_skills TEXT,
        education TEXT,
        status TEXT DEFAULT 'Under Review',
        summary TEXT,
        applied_date TEXT
    )
    """)

    conn.commit()
    conn.close()


def insert_or_update_candidate(candidate_data):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
    INSERT INTO candidates (
        id, name, email, phone, location, role, experience_years,
        overall_score, skills_score, experience_score, education_score, domain_score,
        matched_skills, missing_skills, education, status, summary, applied_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(email) DO UPDATE SET
        overall_score=excluded.overall_score,
        skills_score=excluded.skills_score,
        experience_score=excluded.experience_score,
        matched_skills=excluded.matched_skills,
        missing_skills=excluded.missing_skills,
        status=excluded.status,
        summary=excluded.summary
    """, (
        candidate_data.get("id"),
        candidate_data.get("name"),
        candidate_data.get("email"),
        candidate_data.get("phone"),
        candidate_data.get("location"),
        candidate_data.get("role"),
        candidate_data.get("experience_years"),
        candidate_data.get("overall_score"),
        candidate_data.get("skills_score"),
        candidate_data.get("experience_score"),
        candidate_data.get("education_score"),
        candidate_data.get("domain_score"),
        json.dumps(candidate_data.get("matched_skills", [])),
        json.dumps(candidate_data.get("missing_skills", [])),
        candidate_data.get("education"),
        candidate_data.get("status", "Under Review"),
        candidate_data.get("summary"),
        candidate_data.get("applied_date")
    ))

    conn.commit()
    conn.close()


def get_all_candidates():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM candidates ORDER BY overall_score DESC")
    rows = cursor.fetchall()
    candidates = []
    for r in rows:
        c = dict(r)
        c["matched_skills"] = json.loads(c["matched_skills"] or "[]")
        c["missing_skills"] = json.loads(c["missing_skills"] or "[]")
        candidates.append(c)
    conn.close()
    return candidates


def update_candidate_status(cand_id, new_status):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("UPDATE candidates SET status = ? WHERE id = ?", (new_status, cand_id))
    conn.commit()
    conn.close()


def delete_candidate(cand_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM candidates WHERE id = ?", (cand_id,))
    conn.commit()
    conn.close()
