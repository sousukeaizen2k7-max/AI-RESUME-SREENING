"""
AI Resume Screening System - Python NLP Processor
Provides server-side resume parsing, TF-IDF cosine similarity vectorization,
and multi-factor candidate scoring against job descriptions.
"""

import re
import os
from typing import Dict, Any, List

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


class PythonNLPProcessor:
    def __init__(self):
        self.skills_taxonomy = {
            "languages": ["python", "javascript", "typescript", "java", "c++", "c#", "go", "rust", "ruby", "php", "sql", "bash", "html", "css"],
            "frontend": ["react", "next.js", "vue", "angular", "tailwind", "redux", "graphql"],
            "backend": ["node.js", "express", "fastapi", "django", "flask", "spring boot", "rest api", "microservices"],
            "cloud_devops": ["aws", "azure", "gcp", "docker", "kubernetes", "terraform", "ci/cd", "linux", "git", "prometheus", "grafana", "argocd"],
            "aiml": ["machine learning", "deep learning", "nlp", "pytorch", "tensorflow", "scikit-learn", "transformers", "bert", "gpt", "langchain"],
            "databases": ["postgresql", "mongodb", "mysql", "redis", "sqlite", "snowflake", "bigquery"]
        }

        # Flatten list
        self.flat_skills = set()
        for cat, sks in self.skills_taxonomy.items():
            for s in sks:
                self.flat_skills.add(s.lower())

    def extract_text_from_file(self, file_path: str) -> str:
        """Extract text from PDF, DOCX, or TXT file."""
        ext = os.path.splitext(file_path)[1].lower()

        if ext == ".txt":
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()

        elif ext == ".pdf":
            try:
                import pypdf
                reader = pypdf.PdfReader(file_path)
                text = ""
                for page in reader.pages:
                    text += (page.extract_text() or "") + "\n"
                return text
            except Exception as e:
                # Fallback to plain read
                with open(file_path, "rb") as f:
                    content = f.read().decode("latin-1", errors="ignore")
                    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', content)

        elif ext in [".docx", ".doc"]:
            try:
                import docx
                doc = docx.Document(file_path)
                return "\n".join([p.text for p in doc.paragraphs])
            except Exception:
                with open(file_path, "rb") as f:
                    content = f.read().decode("latin-1", errors="ignore")
                    return re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', content)

        return ""

    def extract_entities(self, text: str) -> Dict[str, Any]:
        """Extract structured resume information via RegEx and Taxonomy scanning."""
        lines = [line.strip() for line in text.splitlines() if line.strip()]

        # 1. Candidate Name
        name = "Unknown Candidate"
        for i in range(min(5, len(lines))):
            line = lines[i]
            if "@" in line or "http" in line or len(line) > 35:
                continue
            if re.match(r'^[A-Z][a-zA-Z\.\-']+(\s+[A-Z][a-zA-Z\.\-']+){1,3}$', line):
                name = line
                break

        # 2. Email & Phone
        email_match = re.search(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}', text)
        email = email_match.group(0) if email_match else "Not Found"

        phone_match = re.search(r'(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}', text)
        phone = phone_match.group(0) if phone_match else "Not Found"

        # 3. Location
        loc_match = re.search(r'\b(San Francisco|New York|Seattle|Austin|Boston|Chicago|Denver|San Jose|Los Angeles),\s*([A-Z]{2})\b', text)
        location = loc_match.group(0) if loc_match else "Not Specified"

        # 4. Technical Skills
        lower_text = text.lower()
        found_skills = []
        for skill in self.flat_skills:
            pattern = rf'\b{re.escape(skill)}\b'
            if re.search(pattern, lower_text):
                found_skills.append(skill.title())

        # 5. Experience Years
        exp_match = re.search(r'(\d+(?:\.\d+)?)\s*\+?\s*years?(?:\s+of)?\s+experience', text, re.IGNORECASE)
        if exp_match:
            exp_years = float(exp_match.group(1))
        else:
            exp_years = 4.0

        # 6. Education
        edu_list = []
        if re.search(r'ph\.?d|doctorate', text, re.IGNORECASE):
            edu_list.append("Doctor of Philosophy (Ph.D.)")
        if re.search(r'master of science|m\.?s|master', text, re.IGNORECASE):
            edu_list.append("Master of Science in Computer Science / AI")
        if re.search(r'bachelor of science|b\.?s|b\.?tech|bachelor', text, re.IGNORECASE):
            edu_list.append("Bachelor of Science in Computer Science")

        if not edu_list:
            edu_list.append("Bachelor's Degree in Related Field")

        return {
            "name": name,
            "email": email,
            "phone": phone,
            "location": location,
            "experience_years": exp_years,
            "technical_skills": found_skills,
            "education": edu_list
        }

    def compute_similarity(self, resume_text: str, job_text: str) -> float:
        """Compute TF-IDF Cosine Similarity between resume and job description."""
        if SKLEARN_AVAILABLE:
            try:
                vectorizer = TfidfVectorizer(stop_words='english')
                tfidf_matrix = vectorizer.fit_transform([resume_text, job_text])
                sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
                return float(sim)
            except Exception:
                return 0.75
        else:
            # Fallback word-overlap Jaccard
            words_a = set(re.findall(r'\w+', resume_text.lower()))
            words_b = set(re.findall(r'\w+', job_text.lower()))
            intersection = words_a.intersection(words_b)
            union = words_a.union(words_b)
            return len(intersection) / len(union) if union else 0.5

    def screen_candidate(self, extracted: Dict[str, Any], job_criteria: Dict[str, Any], raw_resume: str) -> Dict[str, Any]:
        """Calculates multi-factor score and insights."""
        req_skills = [s.lower() for s in job_criteria.get("required_skills", [])]
        cand_skills = [s.lower() for s in extracted.get("technical_skills", [])]

        matched = [s.title() for s in req_skills if any(s in cs or cs in s for cs in cand_skills)]
        missing = [s.title() for s in req_skills if not any(s in cs or cs in s for cs in cand_skills)]

        skills_ratio = len(matched) / len(req_skills) if req_skills else 0.8
        skills_score = min(int(skills_ratio * 100), 100)

        min_exp = job_criteria.get("min_experience", 3)
        cand_exp = extracted.get("experience_years", 3)
        exp_score = min(int((cand_exp / min_exp) * 85), 100) if cand_exp < min_exp else min(90 + int(cand_exp - min_exp) * 3, 100)

        edu_score = 90 if any("master" in e.lower() or "ph" in e.lower() for e in extracted.get("education", [])) else 85

        domain_sim = self.compute_similarity(raw_resume, job_criteria.get("description", ""))
        domain_score = min(int(domain_sim * 100 + 15), 100)

        overall = int(skills_score * 0.40 + exp_score * 0.25 + edu_score * 0.15 + domain_score * 0.20)

        status = "Shortlisted" if overall >= 80 else ("Under Review" if overall >= 60 else "Rejected")

        return {
            "overall_score": overall,
            "skills_score": skills_score,
            "experience_score": exp_score,
            "education_score": edu_score,
            "domain_score": domain_score,
            "status": status,
            "matched_skills": matched,
            "missing_skills": missing,
            "summary": f"{extracted.get('name')} achieved an overall match score of {overall}%. Matched {len(matched)} skills."
        }
