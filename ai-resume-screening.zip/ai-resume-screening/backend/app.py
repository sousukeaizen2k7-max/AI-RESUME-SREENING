"""
AI Resume Screening System - Flask REST API & Web Application
"""

from flask import Flask, request, jsonify, send_from_directory
import os
import json
from nlp_processor import PythonNLPProcessor
from database import init_db, get_all_candidates, insert_or_update_candidate, update_candidate_status, delete_candidate

# Initialize Flask app serving frontend root
STATIC_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
app = Flask(__name__, static_folder=STATIC_DIR, static_url_path="")

# Initialize database and NLP processor
init_db()
nlp_engine = PythonNLPProcessor()

@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")

@app.route("/<path:path>")
def static_proxy(path):
    return send_from_directory(STATIC_DIR, path)

@app.route("/api/candidates", methods=["GET"])
def list_candidates():
    """Retrieve all candidates with screening scores."""
    try:
        candidates = get_all_candidates()
        return jsonify({"success": True, "candidates": candidates, "count": len(candidates)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/api/candidates/<cand_id>", methods=["PATCH"])
def patch_candidate(cand_id):
    """Update candidate hiring status (Shortlisted, Under Review, Rejected)."""
    data = request.json or {}
    new_status = data.get("status")
    if not new_status:
        return jsonify({"error": "Status is required"}), 400
    update_candidate_status(cand_id, new_status)
    return jsonify({"success": True, "id": cand_id, "status": new_status})

@app.route("/api/candidates/<cand_id>", methods=["DELETE"])
def remove_candidate(cand_id):
    """Delete a candidate."""
    delete_candidate(cand_id)
    return jsonify({"success": True, "deleted": cand_id})

@app.route("/api/screen", methods=["POST"])
def screen_resume():
    """Screen resume text against job description criteria."""
    data = request.json or {}
    resume_text = data.get("resume_text", "")
    job_criteria = data.get("job_criteria", {})

    if not resume_text:
        return jsonify({"error": "Resume text is required"}), 400

    # 1. Extract entities
    extracted = nlp_engine.extract_entities(resume_text)

    # 2. Evaluate candidate
    screening = nlp_engine.screen_candidate(extracted, job_criteria, resume_text)

    # 3. Save candidate to SQLite
    cand_record = {
        "id": f"cand-{int(os.times().system * 1000)}",
        "name": extracted["name"],
        "email": extracted["email"],
        "phone": extracted["phone"],
        "location": extracted["location"],
        "role": job_criteria.get("title", "Software Engineer"),
        "experience_years": extracted["experience_years"],
        "overall_score": screening["overall_score"],
        "skills_score": screening["skills_score"],
        "experience_score": screening["experience_score"],
        "education_score": screening["education_score"],
        "domain_score": screening["domain_score"],
        "matched_skills": screening["matched_skills"],
        "missing_skills": screening["missing_skills"],
        "education": extracted["education"][0] if extracted["education"] else "Degree",
        "status": screening["status"],
        "summary": screening["summary"],
        "applied_date": "Today"
    }

    try:
        insert_or_update_candidate(cand_record)
    except Exception as e:
        print("Database save error:", e)

    return jsonify({
        "success": True,
        "extracted": extracted,
        "evaluation": screening,
        "candidate": cand_record
    })

@app.route("/api/stats", methods=["GET"])
def get_dashboard_stats():
    """Get recruiter dashboard KPIs and metrics."""
    candidates = get_all_candidates()
    total = len(candidates)
    shortlisted = len([c for c in candidates if c.get("status") == "Shortlisted"])
    avg_score = round(sum(c.get("overall_score", 0) for c in candidates) / total, 1) if total > 0 else 0

    return jsonify({
        "success": True,
        "stats": {
            "total_resumes": total + 20,
            "screened": total,
            "shortlisted": shortlisted,
            "average_score": avg_score
        }
    })

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    print(f"🚀 AI Resume Screening System running at: http://127.0.0.1:{port}")
    app.run(host="0.0.0.0", port=port, debug=True)
