# AI Resume Screening System
> **Smart Resume Screening Powered by AI**

A modern, responsive, and enterprise-grade web application built to help recruiters and hiring teams automatically parse, analyze, match, and rank candidate resumes against complex job descriptions using Natural Language Processing (NLP) and Artificial Intelligence.

---

## 🌟 Key Highlights & Capabilities

- **Zero-Friction Ingestion**: Accepts PDF, DOCX, DOC, and TXT resumes via drag-and-drop or file selection.
- **Automated Named Entity Recognition (NER)**: Extracts candidate contact info (Email, Phone, Location, LinkedIn, GitHub), degree accreditations, years of experience, work history timeline, technical skills taxonomy, and certifications.
- **Semantic & TF-IDF Vector Matching**: Evaluates true contextual relevance and skill frequency rather than basic keyword counts.
- **Multi-Factor Weighted Scoring Engine**:
  - **40%** Technical Skills Match
  - **25%** Experience Level Alignment
  - **15%** Education & Credentials
  - **20%** Domain & Semantic Cosine Similarity
- **Transparent Bias-Free Evaluation**: Objective matching with side-by-side job comparisons, matching vs. missing skill alerts, and tailored technical interview questions.
- **Dynamic Recruiter Dashboard & Analytics**: Interactive Chart.js visualizations for score distribution, candidate pipeline status, skill supply vs. demand, and daily screening velocity.
- **Instant Testing**: Preloaded with realistic sample candidate resumes and preset job descriptions.

---

## 📁 Project Structure

```
ai-resume-screening/
│
├── index.html                     # Main application with all 6 core sections & sidebar navigation
├── server.js                      # Zero-dependency Node.js HTTP server (ready to run with `node server.js`)
├── README.md                      # Comprehensive documentation and setup guide
│
├── css/
│   ├── main.css                   # Responsive layout, modern variables, typography, sidebar, topbar
│   ├── components.css             # Cards, circular gauge, dropzone, table, badges, KPI widgets
│   └── animations.css             # Keyframe animations (pulse, radar sweep, scan line, modals)
│
├── js/
│   ├── app.js                     # Core application state, tabs, uploads, filtering, sorting, actions
│   ├── nlp-engine.js              # Client-side NLP parser: NER extraction, TF-IDF cosine similarity, multi-factor scoring
│   ├── sample-data.js             # Pre-screened candidates, sample jobs, technical skills taxonomy
│   └── charts-manager.js          # Chart.js initialization & dynamic updates (Radar, Distribution, Pipeline, Skills)
│
├── backend/                       # Python Flask + SQLite Backend Architecture
│   ├── app.py                     # Flask REST API endpoints (/api/screen, /api/candidates, /api/stats)
│   ├── nlp_processor.py           # Python scikit-learn TF-IDF & RegEx entity extractor
│   ├── database.py                # SQLite database manager & candidate persistence
│   ├── seed_data.py               # Database seeder with sample candidate records
│   └── requirements.txt           # Python dependencies (Flask, scikit-learn, pypdf, python-docx)
│
└── samples/                       # Pre-built realistic candidate resumes for 1-click testing
    ├── sample_resume_fullstack.txt
    ├── sample_resume_datascience.txt
    └── sample_resume_devops.txt
```

---

## 🚀 How to Run the Website

### Option 1: Quick Launch with Node.js (Recommended)
This workspace already has Node.js installed. Run the built-in server with zero external dependencies:

```bash
# In the project directory:
node server.js
```
Open your browser and navigate to: **`http://127.0.0.1:3000`**

---

### Option 2: Run directly in your Web Browser (Zero Setup)
Simply double-click on `index.html` or open it with Google Chrome, Microsoft Edge, or Firefox. All NLP parsing, entity extraction, vector matching, filtering, and charts run completely client-side in the browser!

---

### Option 3: Python Flask + SQLite Backend
If you wish to run the full Python REST API backend:

```bash
cd backend
pip install -r requirements.txt
python seed_data.py
python app.py
```
The Flask server will start on: **`http://127.0.0.1:5000`**

---

## 🖥️ Screen & Workflow Overview

### 1. Home Page
- AI/recruitment-themed hero section with live simulated radar scan card.
- Core value propositions: Named Entity Recognition, Vector Cosine Similarity, Bias-Free Scoring, Automated Leaderboards.
- 3-step visual workflow and performance metrics (99.4% accuracy, 10x faster screening).

### 2. Resume Upload
- Clean split-screen upload view.
- Drag-and-drop dropzone with format validation (`.pdf`, `.docx`, `.doc`, `.txt`) and animated progress bar.
- **Quick Test Dropdown**: Click to instantly load pre-built sample resumes for Alex Rivera (Full Stack), Dr. Sophia Chen (AI/ML), or Marcus Vance (DevOps).
- Interactive required skills tag manager: add custom skills with `Enter`, click to remove tags.
- Job preset loader with pre-configured descriptions, required experience, and education levels.

### 3. AI Resume Analysis
- Extracted Candidate Profile: Name, Email, Phone, Location, LinkedIn, GitHub.
- Categorized technical skills taxonomy with match checkmarks.
- Chronological work history timeline with company tenures and key bullet accomplishments.
- Degrees and certifications cards.

### 4. Screening Results
- Circular animated SVG score gauge (e.g., 92%) with color-coded verdict badge.
- Factor progress bars: Skills Match, Experience Level, Education, and Domain Relevance.
- Matching vs. Missing skills comparison cards.
- Interactive **Radar Chart** comparing candidate proficiency vs. position benchmark across 6 dimensions.
- AI Recruiter Synthesis: executive summary, candidate strengths, and customized interview discussion points tailored to detected skill gaps.
- Action buttons: "Shortlist Candidate", "Print / Export Report", "Screen Another Resume".

### 5. Candidate Ranking
- Leaderboard table displaying: **Rank | Candidate | Skills Match | Experience | Overall Score | Status | Actions**.
- Real-time search by candidate name, email, or skill.
- Multi-dimensional filters: by Job Role, Minimum Score threshold, and Hiring Status.
- Sort by Highest Score, Lowest Score, Years of Experience, or Alphabetical.
- "Export to CSV" button to download candidate evaluation reports.

### 6. Recruiter Dashboard
- Top KPI statistics: Total Resumes Ingested, Resumes Screened, Shortlisted Candidates, Average Match Score.
- 4 interactive charts:
  1. **Score Distribution** (Bar chart histogram)
  2. **Hiring Pipeline Breakdown** (Doughnut chart)
  3. **In-Demand vs. Missing Skills** (Comparative horizontal bar chart)
  4. **Daily Screening Velocity** (Line chart)
- Recent Applications stream with 1-click candidate inspection.

---

## 🧠 NLP & Scoring Formula

The matching algorithm computes a holistic suitability score using the following weighted formula:

$$\text{Overall Score} = (0.40 \times S_{\text{skills}}) + (0.25 \times S_{\text{exp}}) + (0.15 \times S_{\text{edu}}) + (0.20 \times S_{\text{domain}})$$

Where:
- $S_{\text{skills}}$: Ratio of required skills identified in candidate profile + bonus for optional skills.
- $S_{\text{exp}}$: Compares candidate years of experience against the minimum job requirement.
- $S_{\text{edu}}$: Evaluates highest degree attained (Ph.D., Master's, Bachelor's).
- $S_{\text{domain}}$: TF-IDF cosine similarity between tokenized resume text and job description:

$$\text{Cosine Similarity} = \frac{\mathbf{v}_{\text{resume}} \cdot \mathbf{v}_{\text{jd}}}{\|\mathbf{v}_{\text{resume}}\| \|\mathbf{v}_{\text{jd}}\|}$$

---

## 🎨 Design System

- **Colors**: Deep Navy (`#0f172a`), Royal Blue (`#2563eb`), Emerald (`#10b981`), Amber (`#f59e0b`), Rose (`#ef4444`).
- **Typography**: Plus Jakarta Sans.
- **Iconography**: Clean SVG vector icons for AI, search, upload, candidate, and metrics.
- **Responsiveness**: Fully adaptive layout supporting desktop monitors, tablets, and mobile smartphones with a drawer sidebar menu.
