@echo off
title AI Resume Screening System - Web Server
cd /d "%~dp0"
echo ===============================================================
echo Starting AI Resume Screening System Web Server...
echo ===============================================================
node server.js
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Server stopped with error code %ERRORLEVEL%.
    pause
)
