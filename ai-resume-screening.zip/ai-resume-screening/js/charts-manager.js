/**
 * AI Resume Screening System - Charts Manager
 * Handles Chart.js visualization for screening radar, score distribution,
 * pipeline status breakdown, and skill demand metrics.
 */

class ChartsManager {
  constructor() {
    this.radarChart = null;
    this.distributionChart = null;
    this.pipelineChart = null;
    this.skillsChart = null;
    this.velocityChart = null;
  }

  /**
   * Render or update Radar Chart on the Screening Results page
   */
  renderRadarChart(canvasId, radarData) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.radarChart) {
      this.radarChart.destroy();
    }

    const defaultLabels = ["Core Skills", "Experience", "Education", "Cloud & Infra", "Architecture", "Domain Context"];
    const labels = radarData?.labels || defaultLabels;
    const candidateScores = radarData?.candidate || [92, 94, 90, 88, 85, 89];
    const targetScores = radarData?.required || [85, 80, 80, 80, 75, 80];

    this.radarChart = new Chart(ctx, {
      type: "radar",
      data: {
        labels: labels,
        datasets: [
          {
            label: "Candidate Proficiency",
            data: candidateScores,
            backgroundColor: "rgba(37, 99, 235, 0.2)",
            borderColor: "rgba(37, 99, 235, 1)",
            borderWidth: 2.5,
            pointBackgroundColor: "rgba(37, 99, 235, 1)",
            pointBorderColor: "#ffffff",
            pointHoverBackgroundColor: "#ffffff",
            pointHoverBorderColor: "rgba(37, 99, 235, 1)",
            pointRadius: 4
          },
          {
            label: "Job Benchmark Target",
            data: targetScores,
            backgroundColor: "rgba(148, 163, 184, 0.15)",
            borderColor: "rgba(100, 116, 139, 0.8)",
            borderWidth: 2,
            borderDash: [5, 5],
            pointBackgroundColor: "rgba(100, 116, 139, 1)",
            pointBorderColor: "#ffffff",
            pointRadius: 3
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          r: {
            angleLines: { color: "rgba(226, 232, 240, 0.8)" },
            grid: { color: "rgba(226, 232, 240, 0.6)" },
            suggestedMin: 30,
            suggestedMax: 100,
            pointLabels: {
              font: { size: 12, family: "'Plus Jakarta Sans', sans-serif", weight: "600" },
              color: "#334155"
            },
            ticks: {
              stepSize: 20,
              backdropColor: "transparent",
              color: "#94a3b8"
            }
          }
        },
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              boxWidth: 14,
              padding: 16,
              font: { family: "'Plus Jakarta Sans', sans-serif", size: 12 }
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `${context.dataset.label}: ${context.raw}%`;
              }
            }
          }
        }
      }
    });
  }

  /**
   * Render Dashboard Score Distribution Chart
   */
  renderScoreDistribution(canvasId, candidates) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.distributionChart) {
      this.distributionChart.destroy();
    }

    // Tally score buckets
    const buckets = { "90-100%": 0, "80-89%": 0, "70-79%": 0, "60-69%": 0, "<60%": 0 };
    candidates.forEach(c => {
      const s = c.overallScore || 0;
      if (s >= 90) buckets["90-100%"]++;
      else if (s >= 80) buckets["80-89%"]++;
      else if (s >= 70) buckets["70-79%"]++;
      else if (s >= 60) buckets["60-69%"]++;
      else buckets["<60%"]++;
    });

    this.distributionChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: Object.keys(buckets),
        datasets: [{
          label: "Candidates",
          data: Object.values(buckets),
          backgroundColor: [
            "rgba(16, 185, 129, 0.85)", // 90+ Emerald
            "rgba(37, 99, 235, 0.85)",  // 80+ Blue
            "rgba(99, 102, 241, 0.85)", // 70+ Indigo
            "rgba(245, 158, 11, 0.85)", // 60+ Amber
            "rgba(239, 68, 68, 0.85)"   // <60 Rose
          ],
          borderRadius: 8,
          borderSkipped: false
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            padding: 10,
            cornerRadius: 8
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1, color: "#64748b" },
            grid: { color: "rgba(226, 232, 240, 0.6)" }
          },
          x: {
            grid: { display: false },
            ticks: { color: "#475569", font: { weight: "600" } }
          }
        }
      }
    });
  }

  /**
   * Render Pipeline Status Doughnut Chart
   */
  renderPipelineStatus(canvasId, candidates) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.pipelineChart) {
      this.pipelineChart.destroy();
    }

    const counts = { "Shortlisted": 0, "Under Review": 0, "Rejected": 0 };
    candidates.forEach(c => {
      const st = c.status || "Under Review";
      if (counts[st] !== undefined) counts[st]++;
      else counts["Under Review"]++;
    });

    this.pipelineChart = new Chart(ctx, {
      type: "doughnut",
      data: {
        labels: Object.keys(counts),
        datasets: [{
          data: Object.values(counts),
          backgroundColor: [
            "#10b981", // Shortlisted Green
            "#3b82f6", // Under Review Blue
            "#ef4444"  // Rejected Red
          ],
          borderWidth: 3,
          borderColor: "#ffffff",
          hoverOffset: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "68%",
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              boxWidth: 12,
              padding: 14,
              font: { family: "'Plus Jakarta Sans', sans-serif", size: 12 }
            }
          }
        }
      }
    });
  }

  /**
   * Render Top Matched vs Missing Skills Bar Chart
   */
  renderSkillsDemand(canvasId, candidates) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.skillsChart) {
      this.skillsChart.destroy();
    }

    const matchedFreq = {};
    const missingFreq = {};

    candidates.forEach(c => {
      (c.matchedSkills || []).forEach(s => matchedFreq[s] = (matchedFreq[s] || 0) + 1);
      (c.missingSkills || []).forEach(s => missingFreq[s] = (missingFreq[s] || 0) + 1);
    });

    const topSkills = ["React", "Python", "Docker", "AWS", "TypeScript", "Kubernetes", "PostgreSQL", "CI/CD"];

    const matchData = topSkills.map(s => matchedFreq[s] || 0);
    const missData = topSkills.map(s => missingFreq[s] || 0);

    this.skillsChart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: topSkills,
        datasets: [
          {
            label: "Skill Matched",
            data: matchData,
            backgroundColor: "rgba(16, 185, 129, 0.8)",
            borderRadius: 6
          },
          {
            label: "Skill Missing / Gap",
            data: missData,
            backgroundColor: "rgba(239, 68, 68, 0.75)",
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "top",
            labels: { boxWidth: 12, font: { family: "'Plus Jakarta Sans', sans-serif", size: 12 } }
          }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: "#475569", font: { weight: "500" } }
          },
          y: {
            beginAtZero: true,
            ticks: { stepSize: 1, color: "#64748b" },
            grid: { color: "rgba(226, 232, 240, 0.6)" }
          }
        }
      }
    });
  }

  /**
   * Render Screening Velocity Line Chart
   */
  renderVelocityChart(canvasId) {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return;

    if (this.velocityChart) {
      this.velocityChart.destroy();
    }

    const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const counts = [18, 25, 34, 29, 42, 19, 23];

    this.velocityChart = new Chart(ctx, {
      type: "line",
      data: {
        labels: days,
        datasets: [{
          label: "Resumes Screened",
          data: counts,
          borderColor: "#2563eb",
          backgroundColor: "rgba(37, 99, 235, 0.08)",
          fill: true,
          tension: 0.35,
          borderWidth: 2.5,
          pointBackgroundColor: "#2563eb",
          pointRadius: 4,
          pointHoverRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: { cornerRadius: 8, padding: 10 }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { color: "#64748b" },
            grid: { color: "rgba(226, 232, 240, 0.6)" }
          },
          x: {
            grid: { display: false },
            ticks: { color: "#64748b" }
          }
        }
      }
    });
  }
}

// Global charts instance
window.chartsManager = new ChartsManager();
