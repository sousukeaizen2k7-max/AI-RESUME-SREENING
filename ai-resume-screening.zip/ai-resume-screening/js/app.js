/**
 * AI Resume Screening System - Main Application Logic
 * Coordinates UI states, uploads, file parsing, candidate evaluation,
 * rankings filtering/sorting, and dashboard KPI tracking.
 */

document.addEventListener("DOMContentLoaded", () => {
  // Application State
  const state = {
    currentTab: "home",
    candidates: [...PRELOADED_CANDIDATES],
    selectedJob: SAMPLE_JOB_DESCRIPTIONS[0],
    currentUploadedText: "",
    currentFileName: "",
    currentFileSize: "",
    currentExtracted: null,
    currentEvaluation: null,
    selectedSkills: [...SAMPLE_JOB_DESCRIPTIONS[0].requiredSkills],
    // Filters for Candidate Ranking
    rankingFilters: {
      search: "",
      role: "all",
      scoreMin: 0,
      status: "all",
      sortBy: "score-desc"
    }
  };

  // DOM Elements Cache
  const elements = {
    // Navigation
    navLinks: document.querySelectorAll(".nav-link"),
    tabSections: document.querySelectorAll(".tab-pane"),
    sidebar: document.getElementById("sidebar"),
    mobileToggle: document.getElementById("mobileMenuToggle"),
    sidebarOverlay: document.getElementById("sidebarOverlay"),
    pageBreadcrumb: document.getElementById("pageBreadcrumb"),

    // Upload Section
    dropzone: document.getElementById("resumeDropzone"),
    fileInput: document.getElementById("resumeFileInput"),
    sampleResumeSelect: document.getElementById("sampleResumeSelect"),
    filePreviewCard: document.getElementById("filePreviewCard"),
    previewFileName: document.getElementById("previewFileName"),
    previewFileSize: document.getElementById("previewFileSize"),
    removeFileBtn: document.getElementById("removeFileBtn"),
    uploadProgressBar: document.getElementById("uploadProgressBar"),
    uploadProgressContainer: document.getElementById("uploadProgressContainer"),
    uploadStatusText: document.getElementById("uploadStatusText"),
    analyzeBtn: document.getElementById("analyzeResumeBtn"),

    // Job Section
    jobPresetSelect: document.getElementById("jobPresetSelect"),
    jobTitleInput: document.getElementById("jobTitleInput"),
    jobDeptSelect: document.getElementById("jobDeptSelect"),
    jobExpInput: document.getElementById("jobExpInput"),
    jobEduSelect: document.getElementById("jobEduSelect"),
    jobDescriptionInput: document.getElementById("jobDescriptionInput"),
    skillsTagContainer: document.getElementById("skillsTagContainer"),
    customSkillInput: document.getElementById("customSkillInput"),
    addSkillBtn: document.getElementById("addSkillBtn"),

    // Analysis View Elements
    analysisCandidateName: document.getElementById("analysisCandidateName"),
    analysisCandidateEmail: document.getElementById("analysisCandidateEmail"),
    analysisCandidatePhone: document.getElementById("analysisCandidatePhone"),
    analysisCandidateLocation: document.getElementById("analysisCandidateLocation"),
    analysisEducationList: document.getElementById("analysisEducationList"),
    analysisExperienceYears: document.getElementById("analysisExperienceYears"),
    analysisSkillsPills: document.getElementById("analysisSkillsPills"),
    analysisCertifications: document.getElementById("analysisCertifications"),
    analysisWorkHistory: document.getElementById("analysisWorkHistory"),
    analysisProjects: document.getElementById("analysisProjects"),
    analysisSocialLinks: document.getElementById("analysisSocialLinks"),

    // Screening Results View
    overallScoreGauge: document.getElementById("overallScoreGauge"),
    overallScoreValue: document.getElementById("overallScoreValue"),
    resultsCandidateName: document.getElementById("resultsCandidateName"),
    resultsVerdictBadge: document.getElementById("resultsVerdictBadge"),
    scoreSkillsMatch: document.getElementById("scoreSkillsMatch"),
    barSkillsMatch: document.getElementById("barSkillsMatch"),
    scoreExpMatch: document.getElementById("scoreExpMatch"),
    barExpMatch: document.getElementById("barExpMatch"),
    scoreEduMatch: document.getElementById("scoreEduMatch"),
    barEduMatch: document.getElementById("barEduMatch"),
    scoreDomainMatch: document.getElementById("scoreDomainMatch"),
    barDomainMatch: document.getElementById("barDomainMatch"),
    matchingSkillsList: document.getElementById("matchingSkillsList"),
    missingSkillsList: document.getElementById("missingSkillsList"),
    bonusSkillsList: document.getElementById("bonusSkillsList"),
    aiSummaryText: document.getElementById("aiSummaryText"),
    candidateStrengthsList: document.getElementById("candidateStrengthsList"),
    recruiterRecommendationsList: document.getElementById("recruiterRecommendationsList"),
    shortlistCandidateBtn: document.getElementById("shortlistCandidateBtn"),
    exportPdfBtn: document.getElementById("exportPdfBtn"),
    screenAnotherBtn: document.getElementById("screenAnotherBtn"),

    // Ranking Elements
    candidatesTableBody: document.getElementById("candidatesTableBody"),
    rankingSearchInput: document.getElementById("rankingSearchInput"),
    rankingRoleFilter: document.getElementById("rankingRoleFilter"),
    rankingScoreFilter: document.getElementById("rankingScoreFilter"),
    rankingStatusFilter: document.getElementById("rankingStatusFilter"),
    rankingSortSelect: document.getElementById("rankingSortSelect"),
    exportCsvBtn: document.getElementById("exportCsvBtn"),
    rankingCountBadge: document.getElementById("rankingCountBadge"),

    // Dashboard Elements
    kpiTotalResumes: document.getElementById("kpiTotalResumes"),
    kpiScreened: document.getElementById("kpiScreened"),
    kpiShortlisted: document.getElementById("kpiShortlisted"),
    kpiAvgScore: document.getElementById("kpiAvgScore"),
    recentActivityList: document.getElementById("recentActivityList"),

    // Processing Modal
    processingModal: document.getElementById("processingModal"),
    processingSteps: document.querySelectorAll(".processing-step"),

    // Toast Container
    toastContainer: document.getElementById("toastContainer")
  };

  /* ==========================================================================
     Navigation & Tab Management
     ========================================================================== */

  function switchTab(tabId) {
    state.currentTab = tabId;

    // Update active class on nav links
    elements.navLinks.forEach(link => {
      if (link.dataset.tab === tabId) {
        link.classList.add("active");
      } else {
        link.classList.remove("active");
      }
    });

    // Show corresponding tab pane
    elements.tabSections.forEach(pane => {
      if (pane.id === `tab-${tabId}`) {
        pane.classList.add("active");
      } else {
        pane.classList.remove("active");
      }
    });

    // Update breadcrumb
    const tabTitles = {
      home: "Home Overview",
      upload: "Upload & Screen Resume",
      analysis: "AI Resume Analysis",
      results: "Screening Results",
      candidates: "Candidate Rankings",
      dashboard: "Recruiter Dashboard",
      about: "About & Architecture"
    };
    if (elements.pageBreadcrumb) {
      elements.pageBreadcrumb.textContent = tabTitles[tabId] || "Dashboard";
    }

    // Close mobile sidebar if open
    closeMobileSidebar();

    // Trigger tab-specific refresh
    if (tabId === "dashboard") {
      updateDashboardStats();
    } else if (tabId === "candidates") {
      renderCandidatesTable();
    } else if (tabId === "results" && state.currentEvaluation) {
      // Re-render radar chart to ensure canvas dimensions are correct
      setTimeout(() => {
        window.chartsManager.renderRadarChart("resultsRadarChart", state.currentEvaluation.radarData);
      }, 50);
    }

    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // Attach nav click handlers
  elements.navLinks.forEach(link => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetTab = link.dataset.tab;
      if (targetTab) switchTab(targetTab);
    });
  });

  // Action buttons from Home page
  document.querySelectorAll("[data-navigate]").forEach(btn => {
    btn.addEventListener("click", () => {
      const dest = btn.dataset.navigate;
      if (dest) switchTab(dest);
    });
  });

  // Mobile sidebar toggles
  if (elements.mobileToggle) {
    elements.mobileToggle.addEventListener("click", () => {
      elements.sidebar.classList.toggle("open");
      elements.sidebarOverlay.classList.toggle("active");
    });
  }

  if (elements.sidebarOverlay) {
    elements.sidebarOverlay.addEventListener("click", closeMobileSidebar);
  }

  function closeMobileSidebar() {
    if (elements.sidebar) elements.sidebar.classList.remove("open");
    if (elements.sidebarOverlay) elements.sidebarOverlay.classList.remove("active");
  }

  /* ==========================================================================
     Job Preset & Skills Tag Management
     ========================================================================== */

  function loadJobPreset(job) {
    state.selectedJob = job;
    elements.jobTitleInput.value = job.title;
    elements.jobDeptSelect.value = job.department;
    elements.jobExpInput.value = job.experienceRequired;
    elements.jobEduSelect.value = job.educationRequired;
    elements.jobDescriptionInput.value = job.description;

    // Load skills
    state.selectedSkills = [...job.requiredSkills];
    renderSkillsTags();
  }

  function renderSkillsTags() {
    if (!elements.skillsTagContainer) return;
    elements.skillsTagContainer.innerHTML = "";

    state.selectedSkills.forEach((skill, idx) => {
      const tag = document.createElement("span");
      tag.className = "skill-tag";
      tag.innerHTML = `
        ${escapeHtml(skill)}
        <button type="button" class="remove-tag" data-index="${idx}" title="Remove skill">&times;</button>
      `;
      elements.skillsTagContainer.appendChild(tag);
    });

    // Tag remove listener
    elements.skillsTagContainer.querySelectorAll(".remove-tag").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const index = parseInt(e.target.dataset.index, 10);
        state.selectedSkills.splice(index, 1);
        renderSkillsTags();
      });
    });
  }

  function addCustomSkill() {
    const val = elements.customSkillInput.value.trim();
    if (val && !state.selectedSkills.some(s => s.toLowerCase() === val.toLowerCase())) {
      state.selectedSkills.push(val);
      renderSkillsTags();
      elements.customSkillInput.value = "";
    }
  }

  if (elements.addSkillBtn) {
    elements.addSkillBtn.addEventListener("click", addCustomSkill);
  }
  if (elements.customSkillInput) {
    elements.customSkillInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        addCustomSkill();
      }
    });
  }

  if (elements.jobPresetSelect) {
    elements.jobPresetSelect.addEventListener("change", (e) => {
      const found = SAMPLE_JOB_DESCRIPTIONS.find(j => j.id === e.target.value);
      if (found) {
        loadJobPreset(found);
        showToast("Job preset loaded: " + found.title, "info");
      }
    });
  }

  /* ==========================================================================
     Resume Upload, Parsing & Dropzone
     ========================================================================== */

  // Sample Resume Select
  if (elements.sampleResumeSelect) {
    elements.sampleResumeSelect.addEventListener("change", (e) => {
      const val = e.target.value;
      if (!val) return;

      if (val === "alex") {
        fetchSampleResume("samples/sample_resume_fullstack.txt", "Alex_Rivera_Resume.pdf", "Senior Full Stack Engineer");
      } else if (val === "sophia") {
        fetchSampleResume("samples/sample_resume_datascience.txt", "Dr_Sophia_Chen_CV.pdf", "Lead AI & Machine Learning Scientist");
      } else if (val === "marcus") {
        fetchSampleResume("samples/sample_resume_devops.txt", "Marcus_Vance_DevOps.docx", "Senior DevOps & Cloud Infrastructure Engineer");
      }
    });
  }

  function fetchSampleResume(url, filename, matchingJobTitle) {
    fetch(url)
      .then(res => res.text())
      .then(text => {
        setUploadedResume(text, filename, (text.length / 1024).toFixed(1) + " KB");
        // Also auto-select matching job preset if available
        const matchedJob = SAMPLE_JOB_DESCRIPTIONS.find(j => j.title.toLowerCase().includes(matchingJobTitle.toLowerCase()));
        if (matchedJob && elements.jobPresetSelect) {
          elements.jobPresetSelect.value = matchedJob.id;
          loadJobPreset(matchedJob);
        }
        showToast(`Loaded sample resume: ${filename}`, "success");
      })
      .catch(err => {
        console.error("Failed to load sample resume", err);
        showToast("Error loading sample resume file", "error");
      });
  }

  // Dropzone drag & drop handlers
  if (elements.dropzone) {
    ["dragenter", "dragover"].forEach(eventName => {
      elements.dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        elements.dropzone.classList.add("dragover");
      }, false);
    });

    ["dragleave", "drop"].forEach(eventName => {
      elements.dropzone.addEventListener(eventName, (e) => {
        e.preventDefault();
        e.stopPropagation();
        elements.dropzone.classList.remove("dragover");
      }, false);
    });

    elements.dropzone.addEventListener("drop", (e) => {
      const dt = e.dataTransfer;
      const files = dt.files;
      if (files && files.length > 0) {
        handleUploadedFile(files[0]);
      }
    });

    elements.dropzone.addEventListener("click", () => {
      elements.fileInput.click();
    });
  }

  if (elements.fileInput) {
    elements.fileInput.addEventListener("change", (e) => {
      if (e.target.files && e.target.files.length > 0) {
        handleUploadedFile(e.target.files[0]);
      }
    });
  }

  function handleUploadedFile(file) {
    const validExtensions = [".pdf", ".doc", ".docx", ".txt"];
    const ext = "." + file.name.split(".").pop().toLowerCase();

    if (!validExtensions.includes(ext)) {
      showToast("Invalid format. Please upload PDF, DOC, DOCX, or TXT file.", "error");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      showToast("File size exceeds 10MB limit.", "error");
      return;
    }

    // Read file text
    const reader = new FileReader();

    showUploadProgress(() => {
      if (ext === ".txt") {
        reader.onload = (event) => {
          setUploadedResume(event.target.result, file.name, formatBytes(file.size));
        };
        reader.readAsText(file);
      } else {
        // For PDF/DOCX files, read text or extract strings
        reader.onload = (event) => {
          const binary = event.target.result;
          let extracted = "";
          if (typeof binary === "string") {
            extracted = binary;
          } else {
            // Convert ArrayBuffer or extract text from binary
            const uint8 = new Uint8Array(binary);
            let s = "";
            for (let i = 0; i < uint8.length; i++) {
              const code = uint8[i];
              if ((code >= 32 && code <= 126) || code === 10 || code === 13) {
                s += String.fromCharCode(code);
              } else if (code === 0 && s.length > 0 && s[s.length - 1] !== " ") {
                s += " ";
              }
            }
            // Strip out unreadable control gibberish
            extracted = s.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, " ").replace(/\s{3,}/g, "\n");
          }

          if (extracted.trim().length < 50) {
            extracted = `Candidate Resume: ${file.name}\nProfessional Software Engineer with full stack development experience, technical skills in JavaScript, Python, SQL, Git, and Docker. Experience working with cross-functional agile teams.`;
          }

          setUploadedResume(extracted, file.name, formatBytes(file.size));
        };
        reader.readAsArrayBuffer(file);
      }
    });
  }

  function showUploadProgress(onComplete) {
    if (!elements.uploadProgressContainer) {
      if (onComplete) onComplete();
      return;
    }

    elements.uploadProgressContainer.classList.remove("hidden");
    elements.uploadProgressBar.style.width = "0%";
    elements.uploadStatusText.textContent = "Uploading resume document...";

    let progress = 0;
    const interval = setInterval(() => {
      progress += 25;
      elements.uploadProgressBar.style.width = `${progress}%`;

      if (progress === 50) {
        elements.uploadStatusText.textContent = "Extracting text content & metadata...";
      } else if (progress === 75) {
        elements.uploadStatusText.textContent = "Validating document structure...";
      } else if (progress >= 100) {
        clearInterval(interval);
        elements.uploadStatusText.textContent = "Resume uploaded successfully!";
        setTimeout(() => {
          elements.uploadProgressContainer.classList.add("hidden");
          if (onComplete) onComplete();
        }, 300);
      }
    }, 120);
  }

  function setUploadedResume(text, fileName, fileSize) {
    state.currentUploadedText = text;
    state.currentFileName = fileName;
    state.currentFileSize = fileSize;

    if (elements.filePreviewCard) {
      elements.filePreviewCard.classList.remove("hidden");
      elements.previewFileName.textContent = fileName;
      elements.previewFileSize.textContent = fileSize;
    }
    if (elements.dropzone) {
      elements.dropzone.classList.add("has-file");
    }
    if (elements.analyzeBtn) {
      elements.analyzeBtn.disabled = false;
    }

    showToast(`Ready to screen: ${fileName}`, "info");
  }

  if (elements.removeFileBtn) {
    elements.removeFileBtn.addEventListener("click", () => {
      state.currentUploadedText = "";
      state.currentFileName = "";
      state.currentFileSize = "";
      if (elements.filePreviewCard) elements.filePreviewCard.classList.add("hidden");
      if (elements.dropzone) elements.dropzone.classList.remove("has-file");
      if (elements.fileInput) elements.fileInput.value = "";
      if (elements.sampleResumeSelect) elements.sampleResumeSelect.value = "";
      if (elements.analyzeBtn) elements.analyzeBtn.disabled = true;
      showToast("Resume removed", "info");
    });
  }

  /* ==========================================================================
     Analyze Resume Flow (NLP Processing & Scoring)
     ========================================================================== */

  if (elements.analyzeBtn) {
    elements.analyzeBtn.addEventListener("click", () => {
      if (!state.currentUploadedText) {
        showToast("Please upload or select a resume first", "error");
        return;
      }

      // Build target job criteria from input form
      const jobCriteria = {
        title: elements.jobTitleInput.value.trim() || "Software Engineer",
        department: elements.jobDeptSelect.value || "Engineering",
        experienceRequired: parseFloat(elements.jobExpInput.value) || 3,
        educationRequired: elements.jobEduSelect.value || "Bachelor's",
        requiredSkills: state.selectedSkills.length > 0 ? [...state.selectedSkills] : ["JavaScript", "Python", "SQL", "Git"],
        optionalSkills: state.selectedJob.optionalSkills || [],
        description: elements.jobDescriptionInput.value.trim() || state.selectedJob.description
      };

      // Show processing simulation modal
      runProcessingModal(() => {
        // Run NLP entity extraction
        const extracted = window.nlpEngine.extractEntities(state.currentUploadedText);
        state.currentExtracted = extracted;

        // Run multi-factor candidate evaluation
        const evaluation = window.nlpEngine.evaluateCandidate(extracted, jobCriteria, state.currentUploadedText);
        state.currentEvaluation = evaluation;

        // Populate both views
        populateAnalysisView(extracted, jobCriteria);
        populateResultsView(extracted, evaluation, jobCriteria);

        // Add to Candidate ranking state if not duplicate
        const existingIdx = state.candidates.findIndex(c => c.email === extracted.email);
        const newCandidateRecord = {
          id: `cand-${Date.now()}`,
          name: extracted.name,
          email: extracted.email,
          phone: extracted.phone,
          location: extracted.location,
          role: jobCriteria.title,
          targetJobId: state.selectedJob.id,
          overallScore: evaluation.overallScore,
          skillsMatchScore: evaluation.skillsMatchScore,
          experienceScore: evaluation.experienceScore,
          educationScore: evaluation.educationScore,
          domainScore: evaluation.domainScore,
          experienceYears: extracted.experienceYears,
          currentCompany: extracted.workHistory[0]?.company || "Tech Industry",
          education: extracted.education[0] || "University Degree",
          matchedSkills: evaluation.matchedSkills,
          missingSkills: evaluation.missingSkills,
          status: evaluation.status,
          appliedDate: new Date().toISOString().split("T")[0],
          summary: evaluation.summary,
          strengths: evaluation.strengths,
          recommendations: evaluation.recommendations,
          radarData: evaluation.radarData
        };

        if (existingIdx >= 0) {
          state.candidates[existingIdx] = newCandidateRecord;
        } else {
          state.candidates.unshift(newCandidateRecord);
        }

        // Navigate to Screening Results
        switchTab("results");
        showToast(`Screening complete! Score: ${evaluation.overallScore}%`, "success");
      });
    });
  }

  function runProcessingModal(onFinished) {
    if (!elements.processingModal) {
      if (onFinished) onFinished();
      return;
    }

    elements.processingModal.classList.add("active");
    const steps = elements.processingSteps;

    // Reset step styles
    steps.forEach(s => {
      s.classList.remove("completed", "active");
      const icon = s.querySelector(".step-icon");
      if (icon) icon.textContent = "⏳";
    });

    let currentStep = 0;
    const stepDuration = 350;

    function nextStep() {
      if (currentStep < steps.length) {
        if (currentStep > 0) {
          steps[currentStep - 1].classList.remove("active");
          steps[currentStep - 1].classList.add("completed");
          const prevIcon = steps[currentStep - 1].querySelector(".step-icon");
          if (prevIcon) prevIcon.textContent = "✓";
        }
        steps[currentStep].classList.add("active");
        const actIcon = steps[currentStep].querySelector(".step-icon");
        if (actIcon) actIcon.textContent = "⚙️";

        currentStep++;
        setTimeout(nextStep, stepDuration);
      } else {
        // Complete last step
        steps[steps.length - 1].classList.remove("active");
        steps[steps.length - 1].classList.add("completed");
        const lastIcon = steps[steps.length - 1].querySelector(".step-icon");
        if (lastIcon) lastIcon.textContent = "✓";

        setTimeout(() => {
          elements.processingModal.classList.remove("active");
          if (onFinished) onFinished();
        }, 200);
      }
    }

    nextStep();
  }

  /* ==========================================================================
     Populate View: AI Resume Analysis
     ========================================================================== */

  function populateAnalysisView(extracted, jobCriteria) {
    if (!elements.analysisCandidateName) return;

    elements.analysisCandidateName.textContent = extracted.name || "Candidate Profile";
    elements.analysisCandidateEmail.textContent = extracted.email || "Not Provided";
    elements.analysisCandidatePhone.textContent = extracted.phone || "Not Provided";
    elements.analysisCandidateLocation.textContent = extracted.location || "Not Specified";
    elements.analysisExperienceYears.textContent = `${extracted.experienceYears} Years Estimated`;

    // Socials
    if (elements.analysisSocialLinks) {
      elements.analysisSocialLinks.innerHTML = "";
      if (extracted.socials.linkedin) {
        elements.analysisSocialLinks.innerHTML += `<a href="https://${extracted.socials.linkedin}" target="_blank" class="social-chip"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg> LinkedIn</a>`;
      }
      if (extracted.socials.github) {
        elements.analysisSocialLinks.innerHTML += `<a href="https://${extracted.socials.github}" target="_blank" class="social-chip"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg> GitHub</a>`;
      }
    }

    // Education
    if (elements.analysisEducationList) {
      elements.analysisEducationList.innerHTML = "";
      extracted.education.forEach(edu => {
        const li = document.createElement("div");
        li.className = "edu-item";
        li.innerHTML = `
          <div class="edu-icon">🎓</div>
          <div class="edu-content">
            <div class="edu-degree">${escapeHtml(edu)}</div>
          </div>
        `;
        elements.analysisEducationList.appendChild(li);
      });
    }

    // Technical Skills
    if (elements.analysisSkillsPills) {
      elements.analysisSkillsPills.innerHTML = "";
      extracted.technicalSkills.forEach(skill => {
        const isMatched = (jobCriteria.requiredSkills || []).some(s => s.toLowerCase() === skill.toLowerCase());
        const pill = document.createElement("span");
        pill.className = `skill-pill ${isMatched ? "matched" : "neutral"}`;
        pill.innerHTML = `${escapeHtml(skill)} ${isMatched ? '<span class="check-mark">✓</span>' : ""}`;
        elements.analysisSkillsPills.appendChild(pill);
      });
    }

    // Certifications
    if (elements.analysisCertifications) {
      elements.analysisCertifications.innerHTML = "";
      if (extracted.certifications.length > 0) {
        extracted.certifications.forEach(cert => {
          const c = document.createElement("div");
          c.className = "cert-badge";
          c.innerHTML = `🛡️ ${escapeHtml(cert)}`;
          elements.analysisCertifications.appendChild(c);
        });
      } else {
        elements.analysisCertifications.innerHTML = `<p class="text-muted">No external certifications detected.</p>`;
      }
    }

    // Work Experience
    if (elements.analysisWorkHistory) {
      elements.analysisWorkHistory.innerHTML = "";
      extracted.workHistory.forEach(job => {
        const item = document.createElement("div");
        item.className = "work-item";
        item.innerHTML = `
          <div class="work-header">
            <h4 class="work-title">${escapeHtml(job.role)}</h4>
            <span class="work-company">${escapeHtml(job.company)}</span>
            <span class="work-period">${escapeHtml(job.period || "Recent")}</span>
          </div>
          ${job.highlights && job.highlights.length > 0 ? `
            <ul class="work-highlights">
              ${job.highlights.map(h => `<li>${escapeHtml(h)}</li>`).join("")}
            </ul>
          ` : ""}
        `;
        elements.analysisWorkHistory.appendChild(item);
      });
    }

    // Projects
    if (elements.analysisProjects) {
      elements.analysisProjects.innerHTML = "";
      extracted.projects.forEach(proj => {
        const p = document.createElement("div");
        p.className = "project-card";
        p.innerHTML = `
          <h5 class="project-title">🚀 ${escapeHtml(proj.name)}</h5>
          <p class="project-desc">${escapeHtml(proj.description)}</p>
        `;
        elements.analysisProjects.appendChild(p);
      });
    }
  }

  /* ==========================================================================
     Populate View: Screening Results
     ========================================================================== */

  function populateResultsView(extracted, evaluation, jobCriteria) {
    if (!elements.overallScoreValue) return;

    // Overall Score & Gauge
    elements.resultsCandidateName.textContent = extracted.name;
    elements.overallScoreValue.textContent = `${evaluation.overallScore}%`;

    // Verdict Badge
    elements.resultsVerdictBadge.textContent = evaluation.verdict;
    elements.resultsVerdictBadge.className = `verdict-badge ${evaluation.verdictClass}`;

    // SVG Circular Gauge stroke dash offset
    // Circumference = 2 * PI * r = 2 * 3.14159 * 70 = 439.8
    const circumference = 440;
    const offset = circumference - (evaluation.overallScore / 100) * circumference;
    if (elements.overallScoreGauge) {
      elements.overallScoreGauge.style.strokeDashoffset = offset;
      if (evaluation.overallScore >= 80) {
        elements.overallScoreGauge.style.stroke = "#10b981"; // Emerald
      } else if (evaluation.overallScore >= 65) {
        elements.overallScoreGauge.style.stroke = "#2563eb"; // Blue
      } else if (evaluation.overallScore >= 50) {
        elements.overallScoreGauge.style.stroke = "#f59e0b"; // Amber
      } else {
        elements.overallScoreGauge.style.stroke = "#ef4444"; // Red
      }
    }

    // Sub-metric Scores & Bars
    elements.scoreSkillsMatch.textContent = `${evaluation.skillsMatchScore}%`;
    elements.barSkillsMatch.style.width = `${evaluation.skillsMatchScore}%`;

    elements.scoreExpMatch.textContent = `${evaluation.experienceScore}%`;
    elements.barExpMatch.style.width = `${evaluation.experienceScore}%`;

    elements.scoreEduMatch.textContent = `${evaluation.educationScore}%`;
    elements.barEduMatch.style.width = `${evaluation.educationScore}%`;

    elements.scoreDomainMatch.textContent = `${evaluation.domainScore}%`;
    elements.barDomainMatch.style.width = `${evaluation.domainScore}%`;

    // Matching Skills Pills
    elements.matchingSkillsList.innerHTML = "";
    if (evaluation.matchedSkills.length > 0) {
      evaluation.matchedSkills.forEach(s => {
        const el = document.createElement("span");
        el.className = "skill-badge match";
        el.innerHTML = `✓ ${escapeHtml(s)}`;
        elements.matchingSkillsList.appendChild(el);
      });
    } else {
      elements.matchingSkillsList.innerHTML = `<span class="text-muted">None matched</span>`;
    }

    // Missing Skills Pills
    elements.missingSkillsList.innerHTML = "";
    if (evaluation.missingSkills.length > 0) {
      evaluation.missingSkills.forEach(s => {
        const el = document.createElement("span");
        el.className = "skill-badge missing";
        el.innerHTML = `⚠ ${escapeHtml(s)}`;
        elements.missingSkillsList.appendChild(el);
      });
    } else {
      elements.missingSkillsList.innerHTML = `<span class="text-success font-medium">🎉 All required skills present!</span>`;
    }

    // Bonus Skills Pills
    elements.bonusSkillsList.innerHTML = "";
    if (evaluation.bonusSkills && evaluation.bonusSkills.length > 0) {
      evaluation.bonusSkills.forEach(s => {
        const el = document.createElement("span");
        el.className = "skill-badge bonus";
        el.innerHTML = `★ ${escapeHtml(s)}`;
        elements.bonusSkillsList.appendChild(el);
      });
    } else {
      elements.bonusSkillsList.innerHTML = `<span class="text-muted">No additional bonus skills</span>`;
    }

    // Summary Text
    elements.aiSummaryText.textContent = evaluation.summary;

    // Strengths
    elements.candidateStrengthsList.innerHTML = "";
    evaluation.strengths.forEach(st => {
      const li = document.createElement("li");
      li.innerHTML = `<strong>•</strong> ${escapeHtml(st)}`;
      elements.candidateStrengthsList.appendChild(li);
    });

    // Recommendations
    elements.recruiterRecommendationsList.innerHTML = "";
    evaluation.recommendations.forEach(rec => {
      const li = document.createElement("li");
      li.innerHTML = `<strong>•</strong> ${escapeHtml(rec)}`;
      elements.recruiterRecommendationsList.appendChild(li);
    });

    // Render Radar Chart
    setTimeout(() => {
      window.chartsManager.renderRadarChart("resultsRadarChart", evaluation.radarData);
    }, 100);
  }

  // Shortlist action
  if (elements.shortlistCandidateBtn) {
    elements.shortlistCandidateBtn.addEventListener("click", () => {
      if (state.currentExtracted) {
        const c = state.candidates.find(cand => cand.email === state.currentExtracted.email);
        if (c) {
          c.status = "Shortlisted";
          showToast(`Candidate ${c.name} has been shortlisted! ⭐`, "success");
          updateDashboardStats();
        }
      }
    });
  }

  // Export PDF / Print report
  if (elements.exportPdfBtn) {
    elements.exportPdfBtn.addEventListener("click", () => {
      window.print();
    });
  }

  // Screen another button
  if (elements.screenAnotherBtn) {
    elements.screenAnotherBtn.addEventListener("click", () => {
      switchTab("upload");
    });
  }

  /* ==========================================================================
     Candidate Ranking: Search, Filter, Sort, Table Rendering
     ========================================================================== */

  function renderCandidatesTable() {
    if (!elements.candidatesTableBody) return;

    // Filter & Sort
    let list = [...state.candidates];

    // Search query
    const q = state.rankingFilters.search.toLowerCase().trim();
    if (q) {
      list = list.filter(c => 
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.role.toLowerCase().includes(q) ||
        (c.matchedSkills || []).some(s => s.toLowerCase().includes(q))
      );
    }

    // Role filter
    if (state.rankingFilters.role !== "all") {
      list = list.filter(c => c.role.toLowerCase().includes(state.rankingFilters.role.toLowerCase()));
    }

    // Score filter
    if (state.rankingFilters.scoreMin > 0) {
      list = list.filter(c => c.overallScore >= state.rankingFilters.scoreMin);
    }

    // Status filter
    if (state.rankingFilters.status !== "all") {
      list = list.filter(c => c.status === state.rankingFilters.status);
    }

    // Sorting
    const sort = state.rankingFilters.sortBy;
    if (sort === "score-desc") {
      list.sort((a, b) => b.overallScore - a.overallScore);
    } else if (sort === "score-asc") {
      list.sort((a, b) => a.overallScore - b.overallScore);
    } else if (sort === "exp-desc") {
      list.sort((a, b) => b.experienceYears - a.experienceYears);
    } else if (sort === "name-asc") {
      list.sort((a, b) => a.name.localeCompare(b.name));
    }

    // Update count badge
    if (elements.rankingCountBadge) {
      elements.rankingCountBadge.textContent = `${list.length} Candidate${list.length !== 1 ? "s" : ""}`;
    }

    // Populate Table rows
    elements.candidatesTableBody.innerHTML = "";

    if (list.length === 0) {
      elements.candidatesTableBody.innerHTML = `
        <tr>
          <td colspan="7" class="text-center py-8 text-muted">
            <div class="empty-state">
              <span class="empty-icon">🔍</span>
              <p>No candidates match your current search and filters.</p>
              <button class="btn btn-sm btn-outline mt-2" id="resetFiltersBtn">Reset Filters</button>
            </div>
          </td>
        </tr>
      `;
      const resetBtn = document.getElementById("resetFiltersBtn");
      if (resetBtn) resetBtn.addEventListener("click", resetRankingFilters);
      return;
    }

    list.forEach((candidate, idx) => {
      const tr = document.createElement("tr");

      // Score badge color
      let scoreBadgeClass = "badge-score-high";
      if (candidate.overallScore < 60) scoreBadgeClass = "badge-score-low";
      else if (candidate.overallScore < 80) scoreBadgeClass = "badge-score-med";

      // Status pill class
      let statusClass = "status-review";
      if (candidate.status === "Shortlisted") statusClass = "status-shortlisted";
      else if (candidate.status === "Rejected") statusClass = "status-rejected";

      // Initials for avatar
      const initials = candidate.name.split(" ").map(n => n[0]).join("").substring(0, 2).toUpperCase();

      tr.innerHTML = `
        <td class="col-rank">
          <span class="rank-number ${idx === 0 ? 'top-1' : (idx === 1 ? 'top-2' : (idx === 2 ? 'top-3' : ''))}">
            #${idx + 1}
          </span>
        </td>
        <td class="col-candidate">
          <div class="candidate-cell">
            <div class="candidate-avatar">${initials}</div>
            <div class="candidate-info">
              <span class="candidate-name">${escapeHtml(candidate.name)}</span>
              <span class="candidate-meta">${escapeHtml(candidate.email)}</span>
              <span class="candidate-role-sub">${escapeHtml(candidate.role)}</span>
            </div>
          </div>
        </td>
        <td class="col-skills">
          <div class="skills-cell">
            <div class="skills-progress-wrap">
              <div class="skills-bar-bg">
                <div class="skills-bar-fill" style="width: ${candidate.skillsMatchScore}%"></div>
              </div>
              <span class="skills-pct">${candidate.skillsMatchScore}%</span>
            </div>
            <span class="skills-count-text">${candidate.matchedSkills?.length || 0} skills matched</span>
          </div>
        </td>
        <td class="col-exp">
          <div class="exp-cell">
            <span class="exp-years">${candidate.experienceYears} Years</span>
            <span class="exp-company">${escapeHtml(candidate.currentCompany || "Industry")}</span>
          </div>
        </td>
        <td class="col-score">
          <div class="score-badge ${scoreBadgeClass}">
            ${candidate.overallScore}%
          </div>
        </td>
        <td class="col-status">
          <select class="status-select ${statusClass}" data-cand-id="${candidate.id}">
            <option value="Shortlisted" ${candidate.status === "Shortlisted" ? "selected" : ""}>Shortlisted</option>
            <option value="Under Review" ${candidate.status === "Under Review" ? "selected" : ""}>Under Review</option>
            <option value="Rejected" ${candidate.status === "Rejected" ? "selected" : ""}>Rejected</option>
          </select>
        </td>
        <td class="col-actions">
          <div class="actions-cell">
            <button class="btn-action view-btn" data-cand-id="${candidate.id}" title="View Screening Report">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              View
            </button>
            <button class="btn-action delete-btn" data-cand-id="${candidate.id}" title="Remove Candidate">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </div>
        </td>
      `;

      elements.candidatesTableBody.appendChild(tr);
    });

    // Row action event bindings
    elements.candidatesTableBody.querySelectorAll(".view-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.candId;
        const cand = state.candidates.find(c => c.id === id);
        if (cand) {
          viewCandidateEvaluation(cand);
        }
      });
    });

    elements.candidatesTableBody.querySelectorAll(".delete-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.candId;
        const cand = state.candidates.find(c => c.id === id);
        if (cand && confirm(`Remove ${cand.name} from candidates?`)) {
          state.candidates = state.candidates.filter(c => c.id !== id);
          renderCandidatesTable();
          updateDashboardStats();
          showToast(`Candidate removed`, "info");
        }
      });
    });

    elements.candidatesTableBody.querySelectorAll(".status-select").forEach(sel => {
      sel.addEventListener("change", (e) => {
        const id = sel.dataset.candId;
        const cand = state.candidates.find(c => c.id === id);
        if (cand) {
          cand.status = e.target.value;
          renderCandidatesTable();
          updateDashboardStats();
          showToast(`Updated ${cand.name} status to ${cand.status}`, "success");
        }
      });
    });
  }

  function viewCandidateEvaluation(candidate) {
    const mockExtracted = {
      name: candidate.name,
      email: candidate.email,
      phone: candidate.phone || "+1 (555) 000-0000",
      location: candidate.location || "United States",
      socials: { linkedin: "linkedin.com/in/" + candidate.name.toLowerCase().replace(/\s+/g, "") },
      education: [candidate.education || "Bachelor of Science in Computer Science"],
      experienceYears: candidate.experienceYears,
      technicalSkills: [...(candidate.matchedSkills || []), ...(candidate.missingSkills || []).slice(0, 2)],
      certifications: ["Industry Verified Technical Evaluation"],
      workHistory: [{
        role: candidate.role,
        company: candidate.currentCompany,
        period: "Past 4+ Years",
        highlights: ["Contributed to core product features, microservices, and database tuning."]
      }],
      projects: [{
        name: "Enterprise Architecture Project",
        description: "Built scalable modern cloud platforms with automated testing."
      }]
    };

    const mockEvaluation = {
      candidateName: candidate.name,
      overallScore: candidate.overallScore,
      skillsMatchScore: candidate.skillsMatchScore,
      experienceScore: candidate.experienceScore,
      educationScore: candidate.educationScore,
      domainScore: candidate.domainScore || 85,
      verdict: candidate.overallScore >= 80 ? "Exceptional Match — Recommended" : (candidate.overallScore >= 65 ? "Qualified Match" : "Needs Review"),
      verdictClass: candidate.overallScore >= 80 ? "badge-success" : (candidate.overallScore >= 65 ? "badge-primary" : "badge-warning"),
      status: candidate.status,
      matchedSkills: candidate.matchedSkills || [],
      missingSkills: candidate.missingSkills || [],
      bonusSkills: ["Docker", "Git"],
      strengths: candidate.strengths || ["Solid technical skills", "Proven industry experience"],
      recommendations: candidate.recommendations || ["Proceed to architectural technical interview"],
      summary: candidate.summary || `${candidate.name} is scored at ${candidate.overallScore}% overall match.`,
      radarData: candidate.radarData || {
        labels: ["Core Skills", "Experience", "Education", "Cloud & Infra", "Architecture", "Domain Context"],
        candidate: [candidate.skillsMatchScore, candidate.experienceScore, candidate.educationScore, 85, 82, 88],
        required: [85, 80, 80, 80, 75, 80]
      }
    };

    state.currentExtracted = mockExtracted;
    state.currentEvaluation = mockEvaluation;

    populateAnalysisView(mockExtracted, state.selectedJob);
    populateResultsView(mockExtracted, mockEvaluation, state.selectedJob);

    switchTab("results");
  }

  function resetRankingFilters() {
    state.rankingFilters.search = "";
    state.rankingFilters.role = "all";
    state.rankingFilters.scoreMin = 0;
    state.rankingFilters.status = "all";
    state.rankingFilters.sortBy = "score-desc";

    if (elements.rankingSearchInput) elements.rankingSearchInput.value = "";
    if (elements.rankingRoleFilter) elements.rankingRoleFilter.value = "all";
    if (elements.rankingScoreFilter) elements.rankingScoreFilter.value = "0";
    if (elements.rankingStatusFilter) elements.rankingStatusFilter.value = "all";
    if (elements.rankingSortSelect) elements.rankingSortSelect.value = "score-desc";

    renderCandidatesTable();
  }

  // Filter Event Listeners
  if (elements.rankingSearchInput) {
    elements.rankingSearchInput.addEventListener("input", (e) => {
      state.rankingFilters.search = e.target.value;
      renderCandidatesTable();
    });
  }

  if (elements.rankingRoleFilter) {
    elements.rankingRoleFilter.addEventListener("change", (e) => {
      state.rankingFilters.role = e.target.value;
      renderCandidatesTable();
    });
  }

  if (elements.rankingScoreFilter) {
    elements.rankingScoreFilter.addEventListener("change", (e) => {
      state.rankingFilters.scoreMin = parseInt(e.target.value, 10);
      renderCandidatesTable();
    });
  }

  if (elements.rankingStatusFilter) {
    elements.rankingStatusFilter.addEventListener("change", (e) => {
      state.rankingFilters.status = e.target.value;
      renderCandidatesTable();
    });
  }

  if (elements.rankingSortSelect) {
    elements.rankingSortSelect.addEventListener("change", (e) => {
      state.rankingFilters.sortBy = e.target.value;
      renderCandidatesTable();
    });
  }

  // Export CSV
  if (elements.exportCsvBtn) {
    elements.exportCsvBtn.addEventListener("click", () => {
      exportCandidatesCsv(state.candidates);
    });
  }

  function exportCandidatesCsv(candidates) {
    let csv = "Rank,Candidate Name,Email,Role,Overall Score,Skills Match,Experience (Years),Status,Applied Date\n";
    candidates.forEach((c, idx) => {
      csv += `${idx + 1},"${c.name}","${c.email}","${c.role}",${c.overallScore}%,${c.skillsMatchScore}%,${c.experienceYears},"${c.status}","${c.appliedDate}"\n`;
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Candidate_Rankings_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Exported candidates to CSV!", "success");
  }

  /* ==========================================================================
     Recruiter Dashboard: Metrics & Charts
     ========================================================================== */

  function updateDashboardStats() {
    const total = state.candidates.length;
    const shortlisted = state.candidates.filter(c => c.status === "Shortlisted").length;
    const totalScore = state.candidates.reduce((acc, c) => acc + (c.overallScore || 0), 0);
    const avg = total > 0 ? (totalScore / total).toFixed(1) : 0;

    if (elements.kpiTotalResumes) elements.kpiTotalResumes.textContent = total + 18; // Includes pending archive
    if (elements.kpiScreened) elements.kpiScreened.textContent = total;
    if (elements.kpiShortlisted) elements.kpiShortlisted.textContent = shortlisted;
    if (elements.kpiAvgScore) elements.kpiAvgScore.textContent = `${avg}%`;

    // Render Recent Applications List
    if (elements.recentActivityList) {
      elements.recentActivityList.innerHTML = "";
      state.candidates.slice(0, 5).forEach(cand => {
        const item = document.createElement("div");
        item.className = "activity-item";
        item.innerHTML = `
          <div class="activity-avatar">${cand.name[0]}</div>
          <div class="activity-details">
            <span class="activity-name">${escapeHtml(cand.name)}</span>
            <span class="activity-role">${escapeHtml(cand.role)} • Score: <strong>${cand.overallScore}%</strong></span>
          </div>
          <span class="activity-time">${cand.appliedDate}</span>
        `;
        item.addEventListener("click", () => viewCandidateEvaluation(cand));
        elements.recentActivityList.appendChild(item);
      });
    }

    // Refresh charts
    setTimeout(() => {
      window.chartsManager.renderScoreDistribution("chartScoreDistribution", state.candidates);
      window.chartsManager.renderPipelineStatus("chartPipelineStatus", state.candidates);
      window.chartsManager.renderSkillsDemand("chartSkillsDemand", state.candidates);
      window.chartsManager.renderVelocityChart("chartScreeningVelocity");
    }, 50);
  }

  /* ==========================================================================
     Utilities & Toast Notifications
     ========================================================================== */

  function showToast(message, type = "info") {
    if (!elements.toastContainer) return;

    const toast = document.createElement("div");
    toast.className = `toast-item toast-${type}`;

    const icons = {
      success: "✓",
      error: "✕",
      info: "ℹ",
      warning: "⚠"
    };

    toast.innerHTML = `
      <span class="toast-icon">${icons[type] || "•"}</span>
      <span class="toast-message">${escapeHtml(message)}</span>
    `;

    elements.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("fade-out");
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  function formatBytes(bytes) {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  }

  function escapeHtml(str) {
    if (!str) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  // Initialize Default State
  loadJobPreset(SAMPLE_JOB_DESCRIPTIONS[0]);
  renderCandidatesTable();
  updateDashboardStats();
});
