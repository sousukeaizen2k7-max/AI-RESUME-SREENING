/**
 * AI Resume Screening System - Sample Data & Presets
 * Contains preloaded realistic jobs, pre-screened candidates, and sample resumes
 */

const SAMPLE_JOB_DESCRIPTIONS = [
  {
    id: "job-1",
    title: "Senior Full Stack Engineer",
    department: "Engineering",
    experienceRequired: 5,
    educationRequired: "Bachelor's Degree in Computer Science or related field",
    requiredSkills: ["React", "TypeScript", "Node.js", "Python", "Docker", "AWS", "PostgreSQL", "REST API", "Git", "CI/CD"],
    optionalSkills: ["Kubernetes", "GraphQL", "Redis", "FastAPI", "Terraform", "Next.js"],
    description: `We are seeking an experienced Senior Full Stack Engineer to spearhead our next-generation enterprise cloud platforms. 
In this role, you will design scalable web applications, architect high-performance distributed microservices, and collaborate closely with product managers and designers.

Responsibilities:
- Build and maintain robust user interfaces with React, TypeScript, and modern CSS architecture.
- Design resilient RESTful and GraphQL APIs using Node.js or Python (FastAPI/Django).
- Provision and optimize relational databases like PostgreSQL and caching with Redis.
- Orchestrate cloud infrastructure on AWS leveraging Docker, Kubernetes, and CI/CD automation.
- Drive engineering best practices including unit testing, code reviews, and system documentation.`
  },
  {
    id: "job-2",
    title: "Lead AI & Machine Learning Scientist",
    department: "Data & AI",
    experienceRequired: 4,
    educationRequired: "Master's or Ph.D. in Computer Science, AI, or Data Science",
    requiredSkills: ["Python", "PyTorch", "Scikit-Learn", "NLP", "Transformers", "SQL", "Docker", "GCP", "Git", "FastAPI"],
    optionalSkills: ["TensorFlow", "MLflow", "BigQuery", "LangChain", "Kubernetes", "BERT"],
    description: `Join our cutting-edge AI Research and Applied Intelligence division as a Lead Machine Learning Scientist. 
You will invent, fine-tune, and deploy state-of-the-art Natural Language Processing (NLP) models and generative AI systems serving millions of users.

Responsibilities:
- Architect and train deep learning models using PyTorch, Hugging Face Transformers, and Scikit-Learn.
- Build production NLP pipelines for document classification, NER entity extraction, and semantic search.
- Collaborate with MLOps to deploy real-time model inference endpoints with Docker and FastAPI on GCP.
- Perform statistical evaluations, A/B model validation, and monitor feature drift in production.`
  },
  {
    id: "job-3",
    title: "Senior DevOps & Cloud Infrastructure Engineer",
    department: "Infrastructure",
    experienceRequired: 5,
    educationRequired: "Bachelor's Degree in IT, Computer Science, or equivalent",
    requiredSkills: ["AWS", "Docker", "Kubernetes", "Terraform", "CI/CD", "Linux", "Python", "Bash", "Prometheus", "Git"],
    optionalSkills: ["ArgoCD", "Ansible", "Azure", "Grafana", "Helm", "Vault"],
    description: `We are looking for a Senior DevOps & Cloud Infrastructure Engineer to own our global multi-region cloud ecosystem. 
You will automate infrastructure deployments, elevate platform reliability, and champion DevSecOps standards.

Responsibilities:
- Build and maintain Infrastructure as Code using Terraform and CloudFormation across AWS environments.
- Manage and scale enterprise Kubernetes (EKS) clusters, Helm charts, and ingress controllers.
- Construct resilient automated CI/CD deployment pipelines using GitHub Actions and ArgoCD.
- Implement proactive monitoring and alerting with Prometheus, Grafana, and Datadog.`
  },
  {
    id: "job-4",
    title: "Frontend UI/UX Engineer",
    department: "Product",
    experienceRequired: 3,
    educationRequired: "Bachelor's Degree in Computer Science, Design, or equivalent",
    requiredSkills: ["JavaScript", "TypeScript", "React", "HTML5", "CSS3", "Tailwind CSS", "Redux", "Git"],
    optionalSkills: ["Next.js", "Figma", "Jest", "GraphQL", "WebSockets"],
    description: `Looking for a passionate Frontend Engineer with a keen eye for design and performance. 
You will build delightful, accessible, and responsive user experiences for our flagship SaaS platform.`
  }
];

const PRELOADED_CANDIDATES = [
  {
    id: "cand-1",
    name: "Alex Rivera",
    email: "alex.rivera@techpulse.io",
    phone: "+1 (555) 234-8901",
    location: "San Francisco, CA",
    role: "Senior Full Stack Engineer",
    targetJobId: "job-1",
    overallScore: 92,
    skillsMatchScore: 95,
    experienceScore: 94,
    educationScore: 90,
    domainScore: 88,
    experienceYears: 6.5,
    currentCompany: "CloudScale Systems",
    education: "B.S. Computer Science, UC Berkeley (2019)",
    matchedSkills: ["React", "TypeScript", "Node.js", "Python", "Docker", "AWS", "PostgreSQL", "REST API", "Git", "CI/CD", "Redis", "FastAPI"],
    missingSkills: ["Kubernetes", "GraphQL"],
    status: "Shortlisted",
    appliedDate: "2026-09-26",
    summary: "Outstanding technical alignment with over 6 years of proven experience in React, Python, Docker, and AWS. Strong architectural background in microservices and database optimization.",
    strengths: [
      "Demonstrated ability to architect high-throughput applications (150k+ daily users)",
      "Full ownership across modern frontend (React/TS) and backend (FastAPI/Node.js/PostgreSQL)",
      "Certified AWS Solutions Architect"
    ],
    recommendations: [
      "Verify hands-on familiarity with production Kubernetes cluster orchestration during technical interview",
      "Evaluate GraphQL schema design expertise"
    ]
  },
  {
    id: "cand-2",
    name: "Dr. Sophia Chen",
    email: "sophia.chen.ai@datamind.org",
    phone: "+1 (555) 789-4321",
    location: "Boston, MA",
    role: "Lead AI & Machine Learning Scientist",
    targetJobId: "job-2",
    overallScore: 94,
    skillsMatchScore: 98,
    experienceScore: 92,
    educationScore: 96,
    domainScore: 93,
    experienceYears: 5.2,
    currentCompany: "NeuralSphere Dynamics",
    education: "M.S. in AI & Data Science, MIT (2019)",
    matchedSkills: ["Python", "PyTorch", "Scikit-Learn", "NLP", "Transformers", "SQL", "Docker", "GCP", "Git", "FastAPI", "BERT", "TensorFlow"],
    missingSkills: ["MLflow", "LangChain"],
    status: "Shortlisted",
    appliedDate: "2026-09-25",
    summary: "Top-tier candidate with advanced academic credentials from MIT and 5+ years of cutting-edge NLP production deployment experience on Google Cloud and PyTorch.",
    strengths: [
      "Extensive experience fine-tuning transformer architectures and reducing latency by 64%",
      "Solid knowledge of NLP pipelines, vector databases, and MLOps on GCP",
      "Google Cloud Certified Professional Machine Learning Engineer"
    ],
    recommendations: [
      "Discuss modern agentic framework experience (LangChain / LlamaIndex)",
      "Explore model governance and monitoring strategies"
    ]
  },
  {
    id: "cand-3",
    name: "Marcus Vance",
    email: "marcus.vance@cloudforge.net",
    phone: "+1 (555) 456-1122",
    location: "Seattle, WA",
    role: "Senior DevOps & Cloud Infrastructure Engineer",
    targetJobId: "job-3",
    overallScore: 91,
    skillsMatchScore: 94,
    experienceScore: 96,
    educationScore: 85,
    domainScore: 90,
    experienceYears: 7.2,
    currentCompany: "Nexus Cloud Systems",
    education: "B.S. Information Technology, Univ. of Washington (2018)",
    matchedSkills: ["AWS", "Docker", "Kubernetes", "Terraform", "CI/CD", "Linux", "Python", "Bash", "Prometheus", "Git", "ArgoCD", "Grafana"],
    missingSkills: ["Ansible", "Vault"],
    status: "Shortlisted",
    appliedDate: "2026-09-24",
    summary: "Senior DevOps practitioner holding dual CKA and AWS Architect credentials with over 7 years managing 400+ microservices on Kubernetes.",
    strengths: [
      "Deep expertise in Terraform Infrastructure as Code and GitOps with ArgoCD",
      "Proven cost optimization saving 34% in multi-account cloud spend",
      "Certified Kubernetes Administrator (CKA)"
    ],
    recommendations: [
      "Examine secret lifecycle automation tools like HashiCorp Vault during interview"
    ]
  },
  {
    id: "cand-4",
    name: "Elena Rostova",
    email: "elena.rostova@devmail.com",
    phone: "+1 (555) 890-3344",
    location: "New York, NY",
    role: "Senior Full Stack Engineer",
    targetJobId: "job-1",
    overallScore: 84,
    skillsMatchScore: 86,
    experienceScore: 85,
    educationScore: 88,
    domainScore: 80,
    experienceYears: 4.8,
    currentCompany: "FinTech Vantage",
    education: "B.S. Software Engineering, NYU (2020)",
    matchedSkills: ["React", "TypeScript", "Node.js", "PostgreSQL", "Docker", "REST API", "Git", "Next.js"],
    missingSkills: ["Python", "AWS", "CI/CD", "Kubernetes"],
    status: "Under Review",
    appliedDate: "2026-09-23",
    summary: "Strong frontend and backend engineer with heavy React, TypeScript, and Node.js skills in financial platforms. Lacks direct AWS cloud and Python exposure.",
    strengths: [
      "Strong TypeScript architecture and state management experience",
      "Solid PostgreSQL optimization and database indexing"
    ],
    recommendations: [
      "Assess willingness and ramp-up timeline to learn Python and AWS services"
    ]
  },
  {
    id: "cand-5",
    name: "Devon Clark",
    email: "devon.clark@cloudstack.co",
    phone: "+1 (555) 321-9988",
    location: "Austin, TX",
    role: "Senior Full Stack Engineer",
    targetJobId: "job-1",
    overallScore: 78,
    skillsMatchScore: 75,
    experienceScore: 82,
    educationScore: 80,
    domainScore: 76,
    experienceYears: 4.0,
    currentCompany: "Austin Tech Hub",
    education: "B.S. Computer Engineering, UT Austin (2021)",
    matchedSkills: ["Python", "Django", "PostgreSQL", "Docker", "REST API", "Git", "AWS"],
    missingSkills: ["React", "TypeScript", "Node.js", "CI/CD"],
    status: "Under Review",
    appliedDate: "2026-09-22",
    summary: "Solid backend-leaning engineer with deep Python, Django, and AWS experience, but limited modern React/TypeScript frontend experience.",
    strengths: ["Strong Python backend architecture and AWS deployment"],
    recommendations: ["Evaluate frontend JavaScript/TypeScript capabilities"]
  },
  {
    id: "cand-6",
    name: "Jessica Nguyen",
    email: "jessica.nguyen@dataai.org",
    phone: "+1 (555) 678-5544",
    location: "Chicago, IL",
    role: "Lead AI & Machine Learning Scientist",
    targetJobId: "job-2",
    overallScore: 81,
    skillsMatchScore: 82,
    experienceScore: 80,
    educationScore: 85,
    domainScore: 78,
    experienceYears: 3.8,
    currentCompany: "Cortex Analytics",
    education: "M.S. Computer Science, Univ. of Illinois (2021)",
    matchedSkills: ["Python", "Scikit-Learn", "SQL", "Docker", "Git", "FastAPI", "TensorFlow"],
    missingSkills: ["PyTorch", "Transformers", "NLP", "GCP"],
    status: "Under Review",
    appliedDate: "2026-09-21",
    summary: "Solid classical ML and tabular predictive modeling background, but less direct exposure to modern LLMs and Hugging Face transformer architectures.",
    strengths: ["Strong tabular machine learning and Scikit-Learn foundation"],
    recommendations: ["Test depth in NLP and deep learning transformer architectures"]
  },
  {
    id: "cand-7",
    name: "Liam O'Connor",
    email: "liam.oconnor@syseng.io",
    phone: "+1 (555) 912-4411",
    location: "Denver, CO",
    role: "Senior DevOps & Cloud Infrastructure Engineer",
    targetJobId: "job-3",
    overallScore: 68,
    skillsMatchScore: 65,
    experienceScore: 72,
    educationScore: 75,
    domainScore: 64,
    experienceYears: 3.2,
    currentCompany: "Peak Cloud Services",
    education: "B.A. Computer Information Systems, Colorado State (2022)",
    matchedSkills: ["AWS", "Linux", "Docker", "Git", "Bash"],
    missingSkills: ["Kubernetes", "Terraform", "CI/CD", "Prometheus", "Python"],
    status: "Rejected",
    appliedDate: "2026-09-20",
    summary: "Has basic cloud administration and Linux system skills, but lacks required enterprise Kubernetes, Infrastructure as Code (Terraform), and CI/CD pipelines.",
    strengths: ["General Linux sysadmin and basic AWS EC2 operations"],
    recommendations: ["Does not meet senior engineering requirements at this time"]
  },
  {
    id: "cand-8",
    name: "Kavita Patel",
    email: "kavita.patel@webstudio.io",
    phone: "+1 (555) 777-6210",
    location: "San Jose, CA",
    role: "Senior Full Stack Engineer",
    targetJobId: "job-1",
    overallScore: 88,
    skillsMatchScore: 90,
    experienceScore: 89,
    educationScore: 88,
    domainScore: 85,
    experienceYears: 5.5,
    currentCompany: "Bay Silicon Labs",
    education: "B.Tech Computer Science, San Jose State (2020)",
    matchedSkills: ["React", "TypeScript", "Node.js", "Python", "Docker", "AWS", "PostgreSQL", "REST API", "Git", "GraphQL"],
    missingSkills: ["Kubernetes", "CI/CD"],
    status: "Shortlisted",
    appliedDate: "2026-09-19",
    summary: "Well-rounded full stack engineer with balanced React/TypeScript frontend and Python/Node.js backend proficiency.",
    strengths: ["Strong GraphQL and REST API design", "5+ years in full stack product development"],
    recommendations: ["Inquire about CI/CD pipeline automation setup"]
  }
];

const SKILL_TAXONOMY = {
  languages: ["JavaScript", "TypeScript", "Python", "Java", "C++", "C#", "Go", "Rust", "Ruby", "PHP", "Swift", "Kotlin", "SQL", "Bash", "HTML5", "CSS3"],
  frontend: ["React", "Next.js", "Vue.js", "Angular", "Svelte", "Redux", "Tailwind CSS", "Bootstrap", "Webpack", "Vite", "GraphQL"],
  backend: ["Node.js", "Express", "FastAPI", "Django", "Flask", "Spring Boot", "NestJS", "Ruby on Rails", "REST API", "Microservices", "gRPC"],
  aiml: ["Machine Learning", "Deep Learning", "NLP", "PyTorch", "TensorFlow", "Scikit-Learn", "Transformers", "BERT", "GPT", "LangChain", "OpenAI", "Computer Vision", "Keras", "Pandas", "NumPy"],
  cloud_devops: ["AWS", "Azure", "GCP", "Docker", "Kubernetes", "Terraform", "CI/CD", "Linux", "Git", "GitHub Actions", "Jenkins", "Ansible", "Helm", "Prometheus", "Grafana", "ArgoCD"],
  databases: ["PostgreSQL", "MongoDB", "MySQL", "Redis", "SQLite", "Elasticsearch", "Cassandra", "Snowflake", "BigQuery", "DynamoDB"]
};
